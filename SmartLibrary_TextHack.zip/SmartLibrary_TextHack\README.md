# SmartLibrary – Intelligent Digital Library Platform

A high-performance algorithmic digital library platform engineered with **Java 21** and **React 18 + Vite**, implementing comprehensive solutions for text indexing, document retrieval, sequence alignment, network resource distribution, conflict approximation, and multi-core parallel analytics.

---

## 🏛️ Project Architecture & DSA Mapping

| Module | Course Outcome | Core Algorithms | SmartLibrary Domain Application |
|---|---|---|---|
| **M1: String Algorithms** | CO1 | KMP, Z-Function, Rabin-Karp, Aho-Corasick | Fast technical keyword search, repeated phrase detection, multi-pattern trie scanning |
| **M2: Suffix Structures** | CO2 | Suffix Array, Kasai's LCP Array, Suffix Automaton (DAWG) | Lexicographical indexing, $O(M \log N)$ binary search, $O(M)$ substring retrieval, longest common phrases |
| **M3: Advanced Dynamic Programming** | CO3 | Levenshtein, Damerau-Levenshtein, Needleman-Wunsch, Smith-Waterman, Matrix-Chain Mult (MCM), Bitmask DP | Search query spell-checking, plagiarism/citation alignment, optimal pipeline parenthesization, topic coverage |
| **M4: Network Flow** | CO4 | Edmonds-Karp, Dinic's Algorithm, Bipartite Matching + König's Theorem | Digital book copy distribution, min-cut bottlenecks, assigning research papers to reviewers without conflicts |
| **M5: NP-Completeness & Approximation** | CO5 | Vertex Cover 2-Approximation (Maximal Matching), Greedy Degree, Exact Solver | Neutralizing conflicting document pairs, Karp reduction pipeline ($3\text{-SAT} \to \text{CLIQUE} \to \text{IND-SET} \to \text{VC}$) |
| **M6: Randomized & Parallel Algorithms** | CO6 | Miller-Rabin, Randomized QuickSort, Reservoir Sampling, Blelloch Parallel Scan, ForkJoin Reduce | Primality verification for cryptographic signatures, document ranking, continuous streaming log sampling, Brent's theorem |

---

## 📂 File Structure

```
SmartLibrary_TextHack/
│
├── backend/
│   └── src/main/java/com/smartlibrary/
│       │
│       ├── Server.java                      # Zero-dependency embedded HTTP REST API Server
│       │
│       └── algorithms/
│           ├── KMP.java                     # Knuth-Morris-Pratt pattern search + LPS array
│           ├── ZFunction.java               # Z-algorithm for repeated phrase detection
│           ├── RabinKarp.java               # Rolling hash string matching + collisions
│           ├── AhoCorasick.java             # Multi-keyword Trie with failure links
│           ├── SuffixArray.java             # Suffix Array & Kasai's O(N) LCP algorithm
│           ├── SuffixAutomaton.java         # Minimal DAWG for O(M) substring queries
│           ├── EditDistance.java            # Levenshtein & Damerau query suggestion
│           ├── SequenceAlignment.java       # Needleman-Wunsch & Smith-Waterman
│           ├── MatrixChainMultiplication.java # MCM Dynamic Programming optimization
│           ├── BitmaskDP.java               # Bitmask DP minimum-cost bundle cover
│           ├── EdmondsKarp.java             # BFS Ford-Fulkerson with min-cut partition
│           ├── Dinic.java                   # Dinic blocking flow with level graphs
│           ├── BipartiteMatching.java       # Paper-reviewer matching + König's theorem
│           ├── VertexCoverApproximation.java # 2-Approximation via maximal matching
│           ├── MillerRabin.java             # Probabilistic/Deterministic primality test
│           ├── RandomizedQuickSort.java     # QuickSort avoiding adversarial worst-case
│           ├── ReservoirSampling.java       # Uniform random stream sampling (Alg R)
│           ├── ParallelReduce.java          # ForkJoin reduction & Brent's theorem
│           ├── ParallelScan.java            # Blelloch Parallel Scan (Up/Down-sweep)
│           └── AlgorithmDemo.java           # Standalone comprehensive test runner
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx                          # Interactive React UI with all 6 modules
│   │   ├── main.jsx                         # React entry point
│   │   └── styles.css                       # Modern dark-theme styling & visualizers
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
│
├── run_backend.bat                          # Double-click script to run backend server
├── run_frontend.bat                         # Double-click script to run React frontend
├── run_demo.bat                             # Double-click script to run CLI demo
└── README.md
```

---

## 🚀 Execution Instructions

### Prerequisites
- **Java**: JDK 17 or higher (Java 21 recommended)
- **Node.js**: v18 or higher with `npm`

---

### Option 1: Running the Complete Interactive Web Application

1. **Start Backend Server**:
   ```cmd
   run_backend.bat
   ```
   Or from terminal:
   ```cmd
   javac -d backend/bin backend/src/main/java/com/smartlibrary/algorithms/*.java backend/src/main/java/com/smartlibrary/Server.java
   java -cp backend/bin com.smartlibrary.Server
   ```
   *The server will start listening at `http://localhost:8080`.*

2. **Start Frontend Dashboard**:
   ```cmd
   run_frontend.bat
   ```
   Or from terminal:
   ```cmd
   cd frontend
   npm install
   npm run dev
   ```
   *Open browser at `http://localhost:5173` to explore all interactive modules.*

---

### Option 2: Running the Standalone CLI Demonstration Suite

You can execute all 19 algorithms in one command without the browser:
```cmd
run_demo.bat
```
Or directly:
```cmd
javac -d backend/bin backend/src/main/java/com/smartlibrary/algorithms/*.java
java -cp backend/bin com.smartlibrary.algorithms.AlgorithmDemo
```

---

## 📡 Backend API Endpoints

- `GET  /api/health` - Server health status and platform metadata
- `GET  /api/documents` - Repository of research papers with abstracts & metrics
- `POST /api/m1/search` - Evaluates KMP, Z-Function, Rabin-Karp, Aho-Corasick
- `POST /api/m2/suffix` - Suffix Array, Kasai LCP, and Suffix Automaton queries
- `POST /api/m3/dp` - Edit Distance, Sequence Alignment, MCM, and Bitmask DP
- `POST /api/m4/network-flow` - Edmonds-Karp, Dinic, and Reviewer Bipartite Matching
- `POST /api/m5/approximation` - Vertex Cover 2-Approximation, Greedy, and Karp reductions
- `POST /api/m6/randomized-parallel` - Miller-Rabin, Randomized QuickSort, Reservoir, Blelloch Scan, Brent's Theorem
- `GET  /api/demo` - Executes entire algorithm suite and returns full diagnostic log
