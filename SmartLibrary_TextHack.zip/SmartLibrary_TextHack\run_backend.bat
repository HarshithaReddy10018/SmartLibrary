@echo off
echo ======================================================================
echo           Starting SmartLibrary Java REST Backend (Port 8080)
echo ======================================================================

if not exist "%~dp0backend\bin" mkdir "%~dp0backend\bin"

echo Compiling Java Sources...
javac -d "%~dp0backend\bin" "%~dp0backend\src\main\java\com\smartlibrary\algorithms\*.java" "%~dp0backend\src\main\java\com\smartlibrary\Server.java"
if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo Compilation succeeded. Starting server...
java -cp "%~dp0backend\bin" com.smartlibrary.Server
pause
