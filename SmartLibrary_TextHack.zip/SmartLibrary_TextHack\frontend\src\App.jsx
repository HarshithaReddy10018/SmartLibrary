import React, { useState, useEffect } from 'react';

const API_BASE = 'http://localhost:8080/api';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [serverOnline, setServerOnline] = useState(false);
  const [documents, setDocuments] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [demoOutput, setDemoOutput] = useState('');
  const [demoLoading, setDemoLoading] = useState(false);

  // M1 state
  const [searchPattern, setSearchPattern] = useState('architecture');
  const [searchText, setSearchText] = useState('');
  const [m1Result, setM1Result] = useState(null);
  const [m1Loading, setM1Loading] = useState(false);

  // M2 state
  const [suffixText, setSuffixText] = useState('banana_library_research_analysis_library_index$');
  const [suffixPattern, setSuffixPattern] = useState('library');
  const [m2Result, setM2Result] = useState(null);
  const [m2Loading, setM2Loading] = useState(false);

  // M3 state
  const [misspelledQuery, setMisspelledQuery] = useState('algotithm');
  const [seq1, setSeq1] = useState('DATASTRUCTURES');
  const [seq2, setSeq2] = useState('ALGORITHMICS');
  const [m3Result, setM3Result] = useState(null);
  const [m3Loading, setM3Loading] = useState(false);

  // M4 state
  const [m4Result, setM4Result] = useState(null);
  const [m4Loading, setM4Loading] = useState(false);

  // M5 state
  const [m5Result, setM5Result] = useState(null);
  const [m5Loading, setM5Loading] = useState(false);

  // M6 state
  const [m6Result, setM6Result] = useState(null);
  const [m6Loading, setM6Loading] = useState(false);

  // Check health and load documents
  useEffect(() => {
    fetch(`${API_BASE}/health`)
      .then(res => res.json())
      .then(data => {
        if (data.status === 'UP') setServerOnline(true);
      })
      .catch(() => setServerOnline(false));

    fetch(`${API_BASE}/documents`)
      .then(res => res.json())
      .then(docs => {
        setDocuments(docs);
        if (docs.length > 0) {
          setSelectedDoc(docs[0]);
          setSearchText(docs[0].abstractText);
        }
      })
      .catch(err => console.error("Could not load documents:", err));
  }, []);

  // Run M1
  const runM1Search = () => {
    setM1Loading(true);
    fetch(`${API_BASE}/m1/search`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: searchText, pattern: searchPattern })
    })
      .then(res => res.json())
      .then(data => {
        setM1Result(data);
        setM1Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM1Loading(false);
      });
  };

  // Run M2
  const runM2Suffix = () => {
    setM2Loading(true);
    fetch(`${API_BASE}/m2/suffix`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: suffixText, pattern: suffixPattern })
    })
      .then(res => res.json())
      .then(data => {
        setM2Result(data);
        setM2Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM2Loading(false);
      });
  };

  // Run M3
  const runM3DP = () => {
    setM3Loading(true);
    fetch(`${API_BASE}/m3/dp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: misspelledQuery, seq1: seq1, seq2: seq2 })
    })
      .then(res => res.json())
      .then(data => {
        setM3Result(data);
        setM3Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM3Loading(false);
      });
  };

  // Run M4
  const runM4Flow = () => {
    setM4Loading(true);
    fetch(`${API_BASE}/m4/network-flow`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        setM4Result(data);
        setM4Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM4Loading(false);
      });
  };

  // Run M5
  const runM5Approx = () => {
    setM5Loading(true);
    fetch(`${API_BASE}/m5/approximation`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        setM5Result(data);
        setM5Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM5Loading(false);
      });
  };

  // Run M6
  const runM6Parallel = () => {
    setM6Loading(true);
    fetch(`${API_BASE}/m6/randomized-parallel`, { method: 'POST' })
      .then(res => res.json())
      .then(data => {
        setM6Result(data);
        setM6Loading(false);
      })
      .catch(err => {
        console.error(err);
        setM6Loading(false);
      });
  };

  // Run Full Demo
  const runFullDemo = () => {
    setDemoLoading(true);
    fetch(`${API_BASE}/demo`)
      .then(res => res.json())
      .then(data => {
        setDemoOutput(data.output);
        setDemoLoading(false);
      })
      .catch(err => {
        setDemoOutput("Error executing full suite: " + err.message);
        setDemoLoading(false);
      });
  };

  return (
    <div className="app-container">
      {/* Sidebar Navigation */}
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">📚</div>
          <div>
            <div className="brand-title">SmartLibrary</div>
            <div className="brand-subtitle">Intelligent Digital Platform</div>
          </div>
        </div>

        <nav className="nav-menu">
          <button
            className={`nav-item ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            <span className="icon">🏛️</span>
            <span>Platform Overview</span>
            <span className="nav-badge">Hub</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm1' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m1'); if (!m1Result) runM1Search(); }}
          >
            <span className="icon">🔍</span>
            <span>M1: String Algorithms</span>
            <span className="nav-badge">CO1</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm2' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m2'); if (!m2Result) runM2Suffix(); }}
          >
            <span className="icon">🧬</span>
            <span>M2: Suffix Structures</span>
            <span className="nav-badge">CO2</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm3' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m3'); if (!m3Result) runM3DP(); }}
          >
            <span className="icon">💡</span>
            <span>M3: Advanced DP</span>
            <span className="nav-badge">CO3</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm4' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m4'); if (!m4Result) runM4Flow(); }}
          >
            <span className="icon">🌐</span>
            <span>M4: Network Flow</span>
            <span className="nav-badge">CO4</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm5' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m5'); if (!m5Result) runM5Approx(); }}
          >
            <span className="icon">🛡️</span>
            <span>M5: Approximation & NP</span>
            <span className="nav-badge">CO5</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'm6' ? 'active' : ''}`}
            onClick={() => { setActiveTab('m6'); if (!m6Result) runM6Parallel(); }}
          >
            <span className="icon">⚡</span>
            <span>M6: Randomized & Parallel</span>
            <span className="nav-badge">CO6</span>
          </button>

          <button
            className={`nav-item ${activeTab === 'console' ? 'active' : ''}`}
            onClick={() => { setActiveTab('console'); if (!demoOutput) runFullDemo(); }}
          >
            <span className="icon">💻</span>
            <span>Live Test Console</span>
            <span className="nav-badge">Runner</span>
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="server-status">
            <span className="status-dot" style={{ backgroundColor: serverOnline ? '#10b981' : '#ef4444' }}></span>
            <span>{serverOnline ? 'Backend Online (Port 8080)' : 'Connecting to Server...'}</span>
          </div>
        </div>
      </aside>

      {/* Main Content View */}
      <main className="main-content">
        <header className="top-bar">
          <div className="top-title">
            <span>
              {activeTab === 'overview' && 'Digital Library Platform Hub'}
              {activeTab === 'm1' && 'Module 1: String Search & Text Algorithms'}
              {activeTab === 'm2' && 'Module 2: Suffix Structures & Document Indexing'}
              {activeTab === 'm3' && 'Module 3: Advanced Dynamic Programming'}
              {activeTab === 'm4' && 'Module 4: Network Flow & Resource Distribution'}
              {activeTab === 'm5' && 'Module 5: NP-Completeness & Conflict Approximation'}
              {activeTab === 'm6' && 'Module 6: Randomized & Multi-Core Parallel Algorithms'}
              {activeTab === 'console' && 'Interactive Algorithm Validation Runner'}
            </span>
            <span className="module-tag">{activeTab.toUpperCase()}</span>
          </div>

          <div className="quick-actions">
            <button className="btn btn-secondary" onClick={() => window.location.reload()}>
              🔄 Refresh
            </button>
            <button className="btn btn-primary" onClick={runFullDemo}>
              ▶ Run Full Suite
            </button>
          </div>
        </header>

        <div className="page-body">
          {/* OVERVIEW TAB */}
          {activeTab === 'overview' && (
            <>
              <div className="grid-4">
                <div className="stat-box">
                  <span className="stat-label">Indexed Documents</span>
                  <span className="stat-value">{documents.length}</span>
                  <span className="stat-sub">Research Papers & Books</span>
                </div>
                <div className="stat-box">
                  <span className="stat-label">Active DSA Modules</span>
                  <span className="stat-value">6 Modules</span>
                  <span className="stat-sub">CO1 through CO6 Complete</span>
                </div>
                <div className="stat-box">
                  <span className="stat-label">Algorithms Implemented</span>
                  <span className="stat-value">19 Core DSA</span>
                  <span className="stat-sub">KMP, Dinic, Blelloch, etc.</span>
                </div>
                <div className="stat-box">
                  <span className="stat-label">Architecture</span>
                  <span className="stat-value">Zero-Dep Java</span>
                  <span className="stat-sub">Pure JDK 21 + React 18</span>
                </div>
              </div>

              {/* Syllabus Mapping Grid */}
              <div className="card">
                <div className="card-header">
                  <div>
                    <h2 className="card-title">🎯 Syllabus DSA Integration Architecture</h2>
                    <p className="card-desc">Where each data structure and algorithm operates within SmartLibrary</p>
                  </div>
                </div>

                <div className="grid-3">
                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-indigo">M1 – CO1</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>String Algorithms</h3>
                    <p style={{ fontSize: '0.82rem', color: '#9ca3af', marginTop: 4 }}>
                      • <strong>KMP:</strong> Technical keyword pattern search<br/>
                      • <strong>Z-Function:</strong> Repeated phrase detection<br/>
                      • <strong>Rabin-Karp:</strong> Rolling hash multi-pattern match<br/>
                      • <strong>Aho-Corasick:</strong> Simultaneous trie scanner
                    </p>
                  </div>

                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-cyan">M2 – CO2</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>Suffix Structures</h3>
                    <p style={{ fontSize: '0.82rem', color: '#9ca3af', marginTop: 4 }}>
                      • <strong>Suffix Array:</strong> Lexicographical document indexing<br/>
                      • <strong>Kasai LCP:</strong> O(N) longest common phrase detection<br/>
                      • <strong>Suffix Automaton:</strong> O(M) substring retrieval & distinct substring count
                    </p>
                  </div>

                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-emerald">M3 – CO3</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>Advanced Dynamic Prog.</h3>
                    <p style={{ fontSize: '0.82rem', color: '#9ca3af', marginTop: 4 }}>
                      • <strong>Levenshtein:</strong> Search typo correction<br/>
                      • <strong>Needleman-Wunsch:</strong> Global sequence alignment<br/>
                      • <strong>Matrix Chain:</strong> Optimum pipeline parenthesization<br/>
                      • <strong>Bitmask DP:</strong> Resource & topic set cover
                    </p>
                  </div>

                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-amber">M4 – CO4</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>Network Flow</h3>
                    <p style={{ fontSize: '0.82rem', color: '#9ca3af', marginTop: 4 }}>
                      • <strong>Bipartite Matching:</strong> Assign papers to reviewers<br/>
                      • <strong>Edmonds-Karp:</strong> Library resource distribution<br/>
                      • <strong>Dinic Algorithm:</strong> Layered blocking flow<br/>
                      • <strong>König's Theorem:</strong> Min vertex cover conflict analysis
                    </p>
                  </div>

                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-rose">M5 – CO5</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>NP-Hard & Approximation</h3>
                    <p style={{ fontSize: '0.82rem', color: '#9ca3af', marginTop: 4 }}>
                      • <strong>Vertex Cover 2-Approx:</strong> Maximal matching factor ≤ 2<br/>
                      • <strong>Greedy Heuristic:</strong> Degree-based vertex cover<br/>
                      • <strong>Karp Reductions:</strong> 3-SAT → CLIQUE → IND-SET → VERTEX-COVER
                    </p>
                  </div>

                  <div className="stat-box" style={{ background: 'rgba(31, 41, 55, 0.4)' }}>
                    <div className="badge badge-purple">M6 – CO6</div>
                    <h3 style={{ marginTop: 8, fontSize: '1rem', color: '#fff' }}>Randomized & Parallel</h3>
                    <p style={{ fontSize: '0.82rem', color: '#fff' }}>
                      • <strong>Miller-Rabin:</strong> Primality test for crypto keys<br/>
                      • <strong>Randomized QuickSort:</strong> Document ranking O(N log N)<br/>
                      • <strong>Reservoir Sampling:</strong> Continuous usage stream<br/>
                      • <strong>Blelloch Scan & Brent:</strong> Multi-core parallel reduce
                    </p>
                  </div>
                </div>
              </div>

              {/* Document Repository Explorer */}
              <div className="card">
                <div className="card-header">
                  <div>
                    <h2 className="card-title">📖 Research Papers Repository</h2>
                    <p className="card-desc">Select a paper to analyze its text using string, suffix, and ranking algorithms</p>
                  </div>
                </div>

                <div className="grid-2">
                  {documents.map(doc => (
                    <div
                      key={doc.id}
                      className={`doc-card ${selectedDoc && selectedDoc.id === doc.id ? 'selected' : ''}`}
                      onClick={() => {
                        setSelectedDoc(doc);
                        setSearchText(doc.abstractText);
                      }}
                    >
                      <div className="doc-title">{doc.title}</div>
                      <div className="doc-meta">
                        <span>👤 {doc.author}</span>
                        <span>📅 {doc.year}</span>
                        <span>🌟 {doc.citations.toLocaleString()} citations</span>
                      </div>
                      <p className="doc-abstract">{doc.abstractText}</p>
                      <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {doc.topics.map(t => (
                          <span key={t} className="badge badge-indigo">{t}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* MODULE 1: STRING SEARCH */}
          {activeTab === 'm1' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">🔍 M1 (CO1): String Pattern Searching Algorithms</h2>
                  <p className="card-desc">Evaluates KMP, Z-Function, Rabin-Karp, and Aho-Corasick multi-keyword trie</p>
                </div>
                <button className="btn btn-primary" onClick={runM1Search} disabled={m1Loading}>
                  {m1Loading ? 'Searching...' : '⚡ Run Search Algorithms'}
                </button>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Search Keyword / Pattern</label>
                  <input
                    type="text"
                    className="input-text"
                    value={searchPattern}
                    onChange={e => setSearchPattern(e.target.value)}
                    placeholder="Enter pattern to search..."
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Active Document</label>
                  <select
                    className="input-text"
                    onChange={e => {
                      const doc = documents.find(d => d.id === parseInt(e.target.value));
                      if (doc) {
                        setSelectedDoc(doc);
                        setSearchText(doc.abstractText);
                      }
                    }}
                    value={selectedDoc ? selectedDoc.id : 1}
                  >
                    {documents.map(d => (
                      <option key={d.id} value={d.id}>{d.title}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Document Text to Search</label>
                <textarea
                  className="textarea"
                  value={searchText}
                  onChange={e => setSearchText(e.target.value)}
                />
              </div>

              {m1Result && (
                <>
                  <div className="grid-4" style={{ marginTop: 16 }}>
                    <div className="stat-box">
                      <span className="stat-label">KMP Matches</span>
                      <span className="stat-value">{m1Result.kmp.matches.length}</span>
                      <span className="stat-sub">{m1Result.kmp.comparisons} comparisons, {(m1Result.kmp.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Z-Function Matches</span>
                      <span className="stat-value">{m1Result.zFunction.matches.length}</span>
                      <span className="stat-sub">{m1Result.zFunction.repeatedCount} repeated patterns, {(m1Result.zFunction.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Rabin-Karp Rolling Hash</span>
                      <span className="stat-value">{m1Result.rabinKarp.matches.length}</span>
                      <span className="stat-sub">{m1Result.rabinKarp.spuriousHits} hash collisions, {(m1Result.rabinKarp.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Aho-Corasick Multi-Pattern</span>
                      <span className="stat-value">{m1Result.ahoCorasick.matches.length}</span>
                      <span className="stat-sub">{m1Result.ahoCorasick.trieNodes} trie nodes, {(m1Result.ahoCorasick.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>
                  </div>

                  {/* LPS Array Table */}
                  <div style={{ marginTop: 20 }}>
                    <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#fff' }}>
                      KMP Prefix Function (LPS Array) for "{m1Result.pattern}"
                    </h3>
                    <div className="array-viewer">
                      {searchPattern.split('').map((char, idx) => (
                        <div key={idx} className="array-cell">
                          <div className="array-cell-index">{char} [{idx}]</div>
                          <div className="array-cell-val">
                            {m1Result.kmp.lps && m1Result.kmp.lps[idx] !== undefined ? m1Result.kmp.lps[idx] : 0}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Aho-Corasick Multi-Keyword Results */}
                  <div style={{ marginTop: 20 }}>
                    <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#fff', marginBottom: 10 }}>
                      Aho-Corasick Simultaneous Keyword Hits
                    </h3>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {m1Result.ahoCorasick.matches.map((m, idx) => (
                        <span key={idx} className="badge badge-emerald">
                          "{m.keyword}" at index [{m.start}..{m.end}]
                        </span>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* MODULE 2: SUFFIX STRUCTURES */}
          {activeTab === 'm2' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">🧬 M2 (CO2): Suffix Structures & Document Indexing</h2>
                  <p className="card-desc">Suffix Array, Kasai's O(N) LCP Array, and Suffix Automaton (DAWG)</p>
                </div>
                <button className="btn btn-primary" onClick={runM2Suffix} disabled={m2Loading}>
                  {m2Loading ? 'Processing...' : '⚡ Compute Suffix Structures'}
                </button>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Document Text for Suffix Indexing</label>
                  <input
                    type="text"
                    className="input-text"
                    value={suffixText}
                    onChange={e => setSuffixText(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Query Substring</label>
                  <input
                    type="text"
                    className="input-text"
                    value={suffixPattern}
                    onChange={e => setSuffixPattern(e.target.value)}
                  />
                </div>
              </div>

              {m2Result && (
                <>
                  <div className="grid-3" style={{ marginTop: 16 }}>
                    <div className="stat-box">
                      <span className="stat-label">Binary Search Occurrences</span>
                      <span className="stat-value">{m2Result.search.occurrences.length}</span>
                      <span className="stat-sub">Found at indices {JSON.stringify(m2Result.search.occurrences)}</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Longest Repeated Phrase (LCP)</span>
                      <span className="stat-value">"{m2Result.longestRepeatedSubstring.text}"</span>
                      <span className="stat-sub">Length: {m2Result.longestRepeatedSubstring.length} characters</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Suffix Automaton (SAM)</span>
                      <span className="stat-value">{m2Result.suffixAutomaton.distinctSubstrings} Substrings</span>
                      <span className="stat-sub">{m2Result.suffixAutomaton.states} DAG states, Substring check: {m2Result.suffixAutomaton.contains ? 'MATCH' : 'NONE'}</span>
                    </div>
                  </div>

                  <div style={{ marginTop: 20 }}>
                    <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#fff' }}>
                      Suffix Array & Kasai LCP Array Breakdown
                    </h3>
                    <div className="array-viewer">
                      {m2Result.suffixArray.map((saVal, idx) => (
                        <div key={idx} className="array-cell">
                          <div className="array-cell-index">Rank #{idx} (SA: {saVal})</div>
                          <div className="array-cell-val" style={{ fontSize: '0.75rem', color: '#a5b4fc' }}>
                            {suffixText.substring(saVal, Math.min(suffixText.length, saVal + 12))}...
                          </div>
                          <div style={{ fontSize: '0.65rem', color: '#10b981', marginTop: 4 }}>
                            LCP: {m2Result.lcp[idx] || 0}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* MODULE 3: ADVANCED DYNAMIC PROGRAMMING */}
          {activeTab === 'm3' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">💡 M3 (CO3): Advanced Dynamic Programming</h2>
                  <p className="card-desc">Query correction, Needleman-Wunsch & Smith-Waterman alignment, Matrix-Chain, and Bitmask DP</p>
                </div>
                <button className="btn btn-primary" onClick={runM3DP} disabled={m3Loading}>
                  {m3Loading ? 'Calculating DP...' : '⚡ Solve All DP Models'}
                </button>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Misspelled Query</label>
                  <input
                    type="text"
                    className="input-text"
                    value={misspelledQuery}
                    onChange={e => setMisspelledQuery(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Sequence 1 (Plagiarism/Citation)</label>
                  <input
                    type="text"
                    className="input-text"
                    value={seq1}
                    onChange={e => setSeq1(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Sequence 2 (Candidate Reference)</label>
                  <input
                    type="text"
                    className="input-text"
                    value={seq2}
                    onChange={e => setSeq2(e.target.value)}
                  />
                </div>
              </div>

              {m3Result && (
                <>
                  <div className="grid-2" style={{ marginTop: 16 }}>
                    {/* Levenshtein Query Correction */}
                    <div className="stat-box">
                      <span className="stat-label">Levenshtein & Damerau Query Correction</span>
                      <h4 style={{ color: '#fff', marginTop: 6, fontSize: '0.95rem' }}>
                        Suggestions for "{m3Result.queryCorrection.query}":
                      </h4>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                        {m3Result.queryCorrection.suggestions.map((s, idx) => (
                          <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', background: '#1f2937', padding: '6px 10px', borderRadius: 6 }}>
                            <span style={{ fontWeight: 600, color: '#6ee7b7' }}>Did you mean: {s.candidate}?</span>
                            <span style={{ color: '#9ca3af' }}>Dist: {s.distance} ({s.similarity}% match)</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Matrix Chain Multiplication */}
                    <div className="stat-box">
                      <span className="stat-label">Matrix-Chain Multiplication Optimization</span>
                      <h4 style={{ color: '#fff', marginTop: 6, fontSize: '0.95rem' }}>
                        Min Scalar Operations: {m3Result.matrixChain.minCost.toLocaleString()}
                      </h4>
                      <div style={{ marginTop: 8, padding: 10, background: '#1f2937', borderRadius: 6, fontFamily: 'monospace', fontSize: '0.85rem', color: '#38bdf8' }}>
                        {m3Result.matrixChain.order}
                      </div>
                      <span className="stat-sub" style={{ marginTop: 6 }}>
                        Optimizes document tokenizer, term matrix, and embedding join pipeline.
                      </span>
                    </div>
                  </div>

                  {/* Needleman-Wunsch vs Smith-Waterman Alignment */}
                  <div className="stat-box" style={{ marginTop: 16 }}>
                    <span className="stat-label">Sequence Alignment (Needleman-Wunsch & Smith-Waterman)</span>
                    <div className="grid-2" style={{ marginTop: 10 }}>
                      <div style={{ background: '#0f172a', padding: 12, borderRadius: 8 }}>
                        <div style={{ fontWeight: 700, color: '#818cf8', marginBottom: 6 }}>
                          Needleman-Wunsch (Global Alignment) - Score: {m3Result.sequenceAlignment.global.score} ({m3Result.sequenceAlignment.global.identity}% identity)
                        </div>
                        <pre style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: '#e2e8f0' }}>
                          Seq 1: {m3Result.sequenceAlignment.global.seq1}{'\n'}
                          Match: {m3Result.sequenceAlignment.global.markers}{'\n'}
                          Seq 2: {m3Result.sequenceAlignment.global.seq2}
                        </pre>
                      </div>

                      <div style={{ background: '#0f172a', padding: 12, borderRadius: 8 }}>
                        <div style={{ fontWeight: 700, color: '#34d399', marginBottom: 6 }}>
                          Smith-Waterman (Local Alignment) - Score: {m3Result.sequenceAlignment.local.score} ({m3Result.sequenceAlignment.local.identity}% identity)
                        </div>
                        <pre style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: '#e2e8f0' }}>
                          Seq 1: {m3Result.sequenceAlignment.local.seq1}{'\n'}
                          Match: {m3Result.sequenceAlignment.local.markers}{'\n'}
                          Seq 2: {m3Result.sequenceAlignment.local.seq2}
                        </pre>
                      </div>
                    </div>
                  </div>

                  {/* Bitmask DP Resource Selection */}
                  <div className="stat-box" style={{ marginTop: 16 }}>
                    <span className="stat-label">Bitmask DP Resource & Topic Coverage Selection</span>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6 }}>
                      <span style={{ fontSize: '1.1rem', fontWeight: 700, color: '#fff' }}>
                        Optimal Acquisition Cost: ${m3Result.bitmaskSelection.minCost}
                      </span>
                      <span className="badge badge-emerald">
                        {m3Result.bitmaskSelection.topicsCovered} Topics Fully Covered
                      </span>
                    </div>

                    <div style={{ display: 'flex', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
                      {m3Result.bitmaskSelection.selected.map((b, idx) => (
                        <div key={idx} style={{ background: '#1e293b', border: '1px solid rgba(255,255,255,0.1)', padding: 10, borderRadius: 8 }}>
                          <div style={{ fontWeight: 600, color: '#f8fafc' }}>{b.title}</div>
                          <div style={{ fontSize: '0.78rem', color: '#10b981' }}>Cost: ${b.cost}</div>
                          <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>Covers: {b.topics.join(', ')}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* MODULE 4: NETWORK FLOW */}
          {activeTab === 'm4' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">🌐 M4 (CO4): Network Flow & Resource Allocation</h2>
                  <p className="card-desc">Edmonds-Karp, Dinic's Algorithm, and Paper-Reviewer Bipartite Matching with König's Theorem</p>
                </div>
                <button className="btn btn-primary" onClick={runM4Flow} disabled={m4Loading}>
                  {m4Loading ? 'Routing Flow...' : '⚡ Execute Flow Algorithms'}
                </button>
              </div>

              {m4Result && (
                <>
                  <div className="grid-3" style={{ marginTop: 16 }}>
                    <div className="stat-box">
                      <span className="stat-label">Edmonds-Karp Max Flow</span>
                      <span className="stat-value">{m4Result.edmondsKarp.maxFlow} Units</span>
                      <span className="stat-sub">{m4Result.edmondsKarp.bottlenecks} Min-Cut Bottlenecks, {(m4Result.edmondsKarp.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Dinic's Algorithm</span>
                      <span className="stat-value">{m4Result.dinic.maxFlow} Units</span>
                      <span className="stat-sub">{m4Result.dinic.phases} Level-Graph Phases, {(m4Result.dinic.timeNanos / 1000).toFixed(1)} µs</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Reviewer Bipartite Matching</span>
                      <span className="stat-value">{m4Result.bipartiteMatching.matchedCount} / {m4Result.bipartiteMatching.totalPapers}</span>
                      <span className="stat-sub">König's Min Cover: {m4Result.bipartiteMatching.konigMinCover.length} nodes</span>
                    </div>
                  </div>

                  {/* Paper-Reviewer Matching Table */}
                  <div style={{ marginTop: 20 }}>
                    <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#fff', marginBottom: 10 }}>
                      Peer Review Paper-Reviewer Conflict-Free Assignments
                    </h3>
                    <div className="grid-3">
                      {m4Result.bipartiteMatching.assignments.map((a, idx) => (
                        <div key={idx} style={{ background: '#1f2937', padding: 12, borderRadius: 8, borderLeft: '4px solid #6366f1' }}>
                          <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#fff' }}>{a.paper}</div>
                          <div style={{ fontSize: '0.78rem', color: '#a5b4fc', marginTop: 4 }}>Assigned to: {a.reviewer}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* MODULE 5: APPROXIMATION */}
          {activeTab === 'm5' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">🛡️ M5 (CO5): NP-Completeness & Conflict Approximation</h2>
                  <p className="card-desc">Vertex Cover 2-Approximation (Maximal Matching), Greedy Heuristic, and Karp Reductions</p>
                </div>
                <button className="btn btn-primary" onClick={runM5Approx} disabled={m5Loading}>
                  {m5Loading ? 'Solving...' : '⚡ Run Vertex Cover Analysis'}
                </button>
              </div>

              {m5Result && (
                <>
                  <div className="grid-3" style={{ marginTop: 16 }}>
                    <div className="stat-box">
                      <span className="stat-label">Exact Optimal Cover</span>
                      <span className="stat-value">{m5Result.exact.size} Documents</span>
                      <span className="stat-sub">Set: {JSON.stringify(m5Result.exact.vertices)}</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">2-Approximation (Maximal Matching)</span>
                      <span className="stat-value">{m5Result.approx2.size} Documents</span>
                      <span className="stat-sub">Ratio: {m5Result.approx2.ratio}x (Guaranteed ≤ 2.0x)</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Greedy Degree Heuristic</span>
                      <span className="stat-value">{m5Result.greedy.size} Documents</span>
                      <span className="stat-sub">Ratio: {m5Result.greedy.ratio}x</span>
                    </div>
                  </div>

                  <div className="stat-box" style={{ marginTop: 20 }}>
                    <span className="stat-label">Computational Reduction Pipeline (Karp)</span>
                    <p style={{ marginTop: 8, fontSize: '0.88rem', color: '#e2e8f0', lineHeight: 1.6 }}>
                      {m5Result.karpReduction}
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          {/* MODULE 6: RANDOMIZED & PARALLEL */}
          {activeTab === 'm6' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">⚡ M6 (CO6): Randomized & Multi-Core Parallel Algorithms</h2>
                  <p className="card-desc">Miller-Rabin, Randomized QuickSort, Reservoir Sampling stream, Blelloch Parallel Scan, and Brent's Theorem</p>
                </div>
                <button className="btn btn-primary" onClick={runM6Parallel} disabled={m6Loading}>
                  {m6Loading ? 'Benchmarking...' : '⚡ Run Randomized & Parallel Suite'}
                </button>
              </div>

              {m6Result && (
                <>
                  <div className="grid-4" style={{ marginTop: 16 }}>
                    <div className="stat-box">
                      <span className="stat-label">Miller-Rabin Primality</span>
                      <span className="stat-value">{m6Result.millerRabin.isPrime ? 'PRIME' : 'COMPOSITE'}</span>
                      <span className="stat-sub">Confidence: {m6Result.millerRabin.confidence}% ({m6Result.millerRabin.rounds} rounds)</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Randomized QuickSort</span>
                      <span className="stat-value">{m6Result.quickSort.randComps} Comps</span>
                      <span className="stat-sub">Deterministic: {m6Result.quickSort.detComps} Comps</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Reservoir Stream Sampling</span>
                      <span className="stat-value">{m6Result.reservoirSampling.capacity} Sampled</span>
                      <span className="stat-sub">From {m6Result.reservoirSampling.totalStream} continuous log events</span>
                    </div>

                    <div className="stat-box">
                      <span className="stat-label">Parallel Reduce & Brent</span>
                      <span className="stat-value">{m6Result.parallelReduce.cores} Cores</span>
                      <span className="stat-sub">Brent Predicted Speedup: {m6Result.parallelReduce.brentsSpeedup}x</span>
                    </div>
                  </div>

                  {/* Blelloch Parallel Scan */}
                  <div className="stat-box" style={{ marginTop: 20 }}>
                    <span className="stat-label">Blelloch Parallel Scan (Prefix Sum)</span>
                    <div style={{ marginTop: 10 }}>
                      <div style={{ fontSize: '0.85rem', color: '#94a3b8' }}>
                        Input Document Views: <code style={{ color: '#fff' }}>{m6Result.parallelScan.input}</code>
                      </div>
                      <div style={{ fontSize: '0.85rem', color: '#38bdf8', marginTop: 4 }}>
                        Cumulative Prefix Sum: <code style={{ color: '#38bdf8' }}>{m6Result.parallelScan.prefixSum}</code> (Tree Span Depth: {m6Result.parallelScan.treeDepth})
                      </div>
                    </div>
                  </div>

                  {/* Reservoir Stream Samples */}
                  <div className="stat-box" style={{ marginTop: 16 }}>
                    <span className="stat-label">Live Reservoir Log Samples (Uniform Random Unbiased)</span>
                    <div className="grid-3" style={{ marginTop: 8 }}>
                      {m6Result.reservoirSampling.samples.map((s, idx) => (
                        <div key={idx} style={{ background: '#111827', padding: 8, borderRadius: 6, fontSize: '0.78rem' }}>
                          <span style={{ color: '#f59e0b', fontWeight: 600 }}>{s.user}</span>: {s.action} ({s.doc})
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* INTERACTIVE ALGORITHM CONSOLE */}
          {activeTab === 'console' && (
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">💻 SmartLibrary Full Algorithm Test Runner</h2>
                  <p className="card-desc">Executes all algorithms in real time via the backend runner</p>
                </div>
                <button className="btn btn-primary" onClick={runFullDemo} disabled={demoLoading}>
                  {demoLoading ? 'Running Algorithms...' : '▶ Re-run Suite'}
                </button>
              </div>

              <div className="terminal-window">
                <div className="terminal-header">
                  <div className="terminal-dots">
                    <span className="dot dot-red"></span>
                    <span className="dot dot-yellow"></span>
                    <span className="dot dot-green"></span>
                  </div>
                  <span>SmartLibrary Terminal Output</span>
                  <span>Port 8080</span>
                </div>
                <pre className="terminal-body">
                  {demoLoading ? 'Executing full algorithm suite...' : demoOutput || 'Click "Re-run Suite" to run all algorithms.'}
                </pre>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
